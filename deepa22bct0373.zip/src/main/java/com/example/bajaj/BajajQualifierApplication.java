package com.example.bajaj;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.nio.file.*;

@SpringBootApplication
public class BajajQualifierApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(BajajQualifierApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        RestTemplate restTemplate = new RestTemplate();

        // Request body
        String body = "{\"name\":\"Deepa S\",\"regNo\":\"22BCT0373\",\"email\":\"deepa.sr25102004@gmailc.om\"}";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(body, headers);

        // Call generateWebhook
        ResponseEntity<String> response = restTemplate.postForEntity(
            "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA",
            request,
            String.class
        );

        System.out.println("GenerateWebhook Response: " + response.getBody());

        // In real test, parse JSON to extract webhook + accessToken
        // Here, load SQL query file (student must update)
        String sqlQuery = Files.readString(Path.of("src/main/resources/sql/question1.sql"));

        // Send to webhook with JWT (placeholder, since actual token comes from response)
        HttpHeaders authHeaders = new HttpHeaders();
        authHeaders.setContentType(MediaType.APPLICATION_JSON);
        authHeaders.set("Authorization", "PLACEHOLDER_ACCESS_TOKEN");

        String jsonBody = "{\"finalQuery\": \"" + sqlQuery.replace(""", "\\"") + "\"}";

        HttpEntity<String> answerReq = new HttpEntity<>(jsonBody, authHeaders);

        // Placeholder POST (students replace with real webhook URL)
        // restTemplate.postForEntity(webhookUrl, answerReq, String.class);

        System.out.println("Submitted finalQuery: " + sqlQuery);
    }
}
